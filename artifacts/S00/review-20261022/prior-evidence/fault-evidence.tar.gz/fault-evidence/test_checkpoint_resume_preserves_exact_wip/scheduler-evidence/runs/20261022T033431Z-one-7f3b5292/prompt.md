Work only on phase one. Read scheduler.json, AGENTS.md, PROGRESS.md and relevant design documents. Implement and test the phase. Do not edit .scheduler/state.json or create Git commits. Return the required structured result. Never declare future phases completed.

Fault injection fixture; compute sum of squares, then real gate.

Resume preserved WIP; inspect git diff first. Checkpoint:
{"head": "09fc9640f3c6c179c9d2ce62098ab5d04af47f9e", "phase": "one", "files": {"acceptance.md": "29dd5b0b07a1a0ca1f95f0b6821d5f1b9ede4bb7a12c9b0d57bd2e2ca91ea210", "feature.py": "8c0d76962745eb89039d183b242db1b9e887daa1632a16964fe3a1ce80907aa1"}}