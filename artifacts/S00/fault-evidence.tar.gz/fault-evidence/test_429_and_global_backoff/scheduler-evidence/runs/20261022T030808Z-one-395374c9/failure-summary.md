quota_wait: CLI failed; see typed events and stderr
