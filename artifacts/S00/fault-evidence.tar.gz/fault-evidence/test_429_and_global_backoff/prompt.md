Fault injection fixture; compute sum of squares, then real gate.
