blocked_input: model changed protected phase graph/gates or Git HEAD
