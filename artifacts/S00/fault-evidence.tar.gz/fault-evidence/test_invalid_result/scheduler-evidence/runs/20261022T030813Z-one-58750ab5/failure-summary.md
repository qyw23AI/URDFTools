partial: invalid structured result
