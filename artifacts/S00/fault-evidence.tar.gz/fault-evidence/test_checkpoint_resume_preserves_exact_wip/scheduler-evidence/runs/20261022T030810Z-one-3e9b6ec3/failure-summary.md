blocked_hardware: fault fixture result
