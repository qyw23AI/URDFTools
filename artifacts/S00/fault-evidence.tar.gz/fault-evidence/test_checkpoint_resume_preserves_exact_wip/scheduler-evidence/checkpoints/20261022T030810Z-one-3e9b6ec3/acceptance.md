Fault fixture: arithmetic gate verifies sum of squares 1..10 = 385.
