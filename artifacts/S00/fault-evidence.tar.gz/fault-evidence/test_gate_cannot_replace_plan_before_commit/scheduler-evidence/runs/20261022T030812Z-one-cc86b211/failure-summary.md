blocked_input: protected phase graph/gates, task inputs or Git HEAD changed
