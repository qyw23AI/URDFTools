wait_model: requested model/effort absent from model/list
