Work only on phase 2. Read scheduler.json, AGENTS.md, PROGRESS.md and relevant design documents. Implement and test the phase. Do not edit .scheduler/state.json or create Git commits. Return the required structured result. Never declare future phases completed.

Fault injection fixture; compute sum of squares, then real gate.
