interrupted: child did not finish within its bound
