partial: fault fixture result
