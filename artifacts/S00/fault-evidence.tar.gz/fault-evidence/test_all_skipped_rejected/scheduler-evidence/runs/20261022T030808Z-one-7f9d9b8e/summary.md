fault fixture result
