partial: missing turn.completed
