partial: invalid JSONL stream
