auth_required: preflight RPC rejected: account/rateLimits/read
