commit_failed: Git commit failed; see git-commit.stdout/stderr
