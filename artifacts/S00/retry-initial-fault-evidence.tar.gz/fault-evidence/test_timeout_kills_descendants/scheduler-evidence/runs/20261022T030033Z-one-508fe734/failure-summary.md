internal_error: [Errno 30] Read-only file system: '/home/qyw/.codex/tmp/urdftools-chatgpt-29hp506l'
