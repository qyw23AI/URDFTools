internal_error: [Errno 30] Read-only file system: '/home/qyw/.codex/tmp/urdftools-chatgpt-3_5_9oxs'
