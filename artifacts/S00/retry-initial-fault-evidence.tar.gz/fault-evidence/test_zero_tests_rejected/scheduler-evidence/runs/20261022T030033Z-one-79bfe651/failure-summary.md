internal_error: [Errno 30] Read-only file system: '/home/qyw/.codex/tmp/urdftools-chatgpt-08guy_8q'
